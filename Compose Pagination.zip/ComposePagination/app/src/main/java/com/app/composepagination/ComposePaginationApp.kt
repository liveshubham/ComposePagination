package com.app.composepagination

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ComposePaginationApp:Application() {
}